<?php
//observers/ResponsableDeCompras.php
class ResponsableDeCompras {
    public function actualizar() {
        // Lógica para recibir notificación de inventario o producción
    }
}
?>
